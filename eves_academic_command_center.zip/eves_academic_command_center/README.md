# Eve's Academic Command Center — starter MVP

## What works now
- Responsive website dashboard for desktop, iPad, and phone.
- Assignment tracker with subjects, due dates, test/quiz type, status, completion, and deletion.
- Manual grade tracker for Algebra 1, Science, and History.
- Rule-based study-plan generator.
- Sample science quiz.
- Agent-role directory for Headmaster, Grade Guardian, Algebra Ace, Science Scholar, History Historian, Exam Coach, and Fact Checker.
- Local browser storage so entries persist in the same browser on the same device.

## Important current limitation
This is a working front-end prototype, **not yet a connected multi-agent AI application**. The agent cards describe the intended roles; they do not call independent AI models. The website does not connect to a school gradebook, and it does not sync data between devices.

## Run it
1. Unzip the folder.
2. Open `index.html` in a modern browser.
3. Add sample assignments and grades. Try the study planner and quiz.

No installation is needed for the prototype.

## Next development stage: real AI agents
A production version should add a server-side backend that:
1. Accepts a request from the website.
2. Routes it to the relevant specialist (Algebra, Science, History, Exam Coach).
3. Uses a coordinator to synthesize the specialists' outputs.
4. Sends factual or mathematical claims through a verification step where appropriate.
5. Stores user data in a database with authentication and deletion/export controls.

Keep API keys on the server in environment variables. Never put an AI API key in browser JavaScript or commit it to a public repository. Use fictional/sample school data during development. Do not collect school portal passwords or student ID numbers.

## Suggested architecture
- Frontend: HTML/CSS/JavaScript prototype (this folder).
- Backend: Node.js + Express or Python + FastAPI.
- Agent orchestration: a small explicit router/coordinator first; only add multiple model calls when they provide measurable value.
- Database: SQLite for local development, then a managed database if deploying.
- AI provider: chosen later, called only from the backend.
- Deployment: a static frontend host plus a secure backend host.

## Suggested milestones
1. Validate the dashboard and data fields with sample data.
2. Add backend API and secure environment-variable configuration.
3. Implement specialist endpoints and shared task context.
4. Add persistent database and user authentication.
5. Add tests, error handling, privacy controls, and deployment.
